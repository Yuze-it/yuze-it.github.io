(function() {
    const floatButtonHTML = `
      <div id="float-button" style="
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background-color: white;
        border: 2px solid black;
        color: black;
        font-size: 14px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        z-index: 9999;
      ">
        <span style="font-weight: bold;">YU</span>
        <span style="font-weight: bold;">ZE</span>
      </div>
    `;
  
    const floatWindowHTML = `
      <div id="float-window" style="
        position: fixed;
        bottom: 80px;
        right: 20px;
        width: 300px;
        background-color: white;
        border: 1px solid #007bff;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        z-index: 9999;
        display: none;
        padding: 10px;
      ">
        <h1>随机抽人</h1>
        <label for="min-value">最小值:</label>
        <input type="number" id="min-value"><br><br>
        <label for="max-value">最大值:</label>
        <input type="number" id="max-value"><br><br>
        <label for="num-picks">抽取人数:</label>
        <input type="number" id="num-picks"><br><br>
        <button id="pick-button">开始抽取</button>
        <div id="result-container" class="result-container"></div>
      </div>
    `;
  
    document.body.insertAdjacentHTML('beforeend', floatButtonHTML);
    document.body.insertAdjacentHTML('beforeend', floatWindowHTML);
  
    let isFloatWindowVisible = false;
  
    function toggleFloatWindow() {
      const floatWindow = document.getElementById('float-window');
      floatWindow.style.display = floatWindow.style.display === 'block' ? 'none' : 'block';
      isFloatWindowVisible = !isFloatWindowVisible;
    }
  
    document.getElementById('float-button').addEventListener('click', toggleFloatWindow);
  
    document.addEventListener('click', function(event) {
      const floatWindow = document.getElementById('float-window');
      if (event.target !== document.getElementById('float-button') && !floatWindow.contains(event.target)) {
        if (isFloatWindowVisible) {
          floatWindow.style.display = 'none';
          isFloatWindowVisible = false;
        }
      }
    });
  
    document.getElementById('pick-button').addEventListener('click', function() {
      const min = parseInt(document.getElementById('min-value').value, 10) || 0;
      const max = parseInt(document.getElementById('max-value').value, 10) || 0;
      const numPicks = parseInt(document.getElementById('num-picks').value, 10) || 1;
  
      if (min >= max || numPicks <= 0) {
        document.getElementById('result-container').innerText = '请输入有效的值';
        return;
      }
  
      const results = [];
      for (let i = 0; i < numPicks; i++) {
        results.push(Math.floor(Math.random() * (max - min + 1)) + min);
      }
  
      document.getElementById('result-container').innerText = '抽取结果: ' + results.join(', ');
    });
  })();
  