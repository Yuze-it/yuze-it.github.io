chrome.runtime.onInstalled.addListener(function() {
  console.log('随机抽人悬浮球已安装');
});
